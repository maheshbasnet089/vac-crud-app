import HeaderNavBar from "../../components/AppBar";

const Home = () => {
  return (
    <div>
      <HeaderNavBar />
    </div>
  );
};

export default Home;

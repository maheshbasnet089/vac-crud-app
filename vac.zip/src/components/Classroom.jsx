import Hello from "./Hello";

const Classroom = () => {
  return (
    <div>
      <h1>Thi is classroom</h1>
      <Hello />
    </div>
  );
};

export default Classroom;

const Hello = () => {
  return <div>Hi!! guys</div>;
};

export default Hello;
